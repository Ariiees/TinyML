from help_code_demo import pytorch2onnx

pytorch2onnx('./saved_models/IEGM_net_valid_split.pkl', './saved_models/PENG_mode', 1250)