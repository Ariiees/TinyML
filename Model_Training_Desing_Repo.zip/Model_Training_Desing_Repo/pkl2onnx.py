from help_code import pytorch2onnx

pytorch2onnx('./saved_models/IEGM_net.pkl', './saved_models/IEGM_net', 1250)