import argparse
import random
import numpy as np
import torch
from torch.utils.data import DataLoader
from copy import deepcopy
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from models.model_quantize import IEGMNet_FFT

from help_code import ToTensor, stats_report, IEGM_DataSET
import time

def fft_transfer(ys_time, SIZE=1250):
    ys_freq = np.zeros((ys_time.shape[0],SIZE))
    ys_time = ys_time.reshape(ys_time.shape[0],-1)
    if len(list(ys_time.size())) == 1:
        ys_freq = np.fft.fft(ys_time)
    else:
        for i in range(ys_time.size(dim=0)):
            y_freq = np.fft.fft(ys_time[i, :])  # calculate fft on series
            ys_freq[i] = y_freq
    return torch.tensor(ys_freq.reshape((ys_time.shape[0], 1, SIZE, 1)))


class FocalLoss(nn.Module):
    def __init__(self, gamma=0, alpha=None, size_average=True):
        super(FocalLoss, self).__init__()
        self.gamma = gamma
        self.alpha = alpha
        if isinstance(alpha, (float, int)): self.alpha = torch.Tensor([alpha, 1 - alpha])
        if isinstance(alpha, list): self.alpha = torch.Tensor(alpha)
        self.size_average = size_average

    def forward(self, input, target):
        if input.dim() > 2:
            input = input.view(input.size(0), input.size(1), -1)  # N,C,H,W => N,C,H*W
            input = input.transpose(1, 2)  # N,C,H*W => N,H*W,C
            input = input.contiguous().view(-1, input.size(2))  # N,H*W,C => N*H*W,C
        target = target.view(-1, 1)

        logpt = F.log_softmax(input)
        logpt = logpt.gather(1, target)
        logpt = logpt.view(-1)
        pt = Variable(logpt.data.exp())

        if self.alpha is not None:
            if self.alpha.type() != input.data.type():
                self.alpha = self.alpha.type_as(input.data)
            at = self.alpha.gather(0, target.data.view(-1))
            logpt = logpt * Variable(at)

        loss = -1 * (1 - pt) ** self.gamma * logpt
        if self.size_average:
            return loss.mean()
        else:
            return loss.sum()

def main():
    seed = 222
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)

    # Hyperparameters
    BATCH_SIZE_TEST = 1
    SIZE = args.size
    TH = args.th
    path_data = args.path_data
    path_records = args.path_record
    path_net = args.path_net
    path_indices = args.path_indices
    stats_file = open(path_records + 'Quantize_report.txt', 'w')
    criterion = FocalLoss()

    # load trained network
    net = IEGMNet_FFT()
    state_dict = torch.load(path_net + 'IEGM_net_quantize_state_dict.pkl', map_location='cpu')
    net.load_state_dict(state_dict)
    net.to('cpu')

    net.eval()
    # Dynamic PTQ
    # net = torch.quantization.quantize_dynamic(
    #     net,
    #     {torch.nn.Linear}
    # )
    net.fuse_model()
    # Statistic PTQ
    net.qconfig = torch.quantization.get_default_qconfig("qnnpack")

    net_prepared = torch.quantization.prepare(net)


    trainset = IEGM_DataSET(root_dir=path_data,
                            indice_dir=path_indices,
                            mode='train',
                            size=SIZE,
                            transform=transforms.Compose([ToTensor()]))

    trainloader = DataLoader(trainset, batch_size=32, shuffle=True, num_workers=0)

    testset = IEGM_DataSET(root_dir=path_data,
                           indice_dir=path_indices,
                           mode='test',
                           size=SIZE,
                           transform=transforms.Compose([ToTensor()]))

    testloader = DataLoader(testset, batch_size=BATCH_SIZE_TEST, shuffle=True, num_workers=0)

    segs_TP = 0
    segs_TN = 0
    segs_FP = 0
    segs_FN = 0
    # breakpoint()
    start = time.time()

    net_prepared.eval()
    with torch.no_grad():
        for data_train in trainloader:
            IEGM_train, labels_train= data_train['IEGM_seg'], data_train['label']
            seg_label = deepcopy(labels_train)
            IEGM_train = torch.cat((IEGM_train, fft_transfer(IEGM_train)), 1)
            IEGM_train = IEGM_train.float()

            outputs_train = net_prepared(IEGM_train)
            loss = criterion(outputs_train, seg_label)
    print('calibrate time:',time.time()-start,'s')

    net_int8 = torch.quantization.convert(net_prepared)

    net_int8.eval()
    with torch.no_grad():
        for data_test in testloader:
            IEGM_test, labels_test = data_test['IEGM_seg'], data_test['label']
            seg_label = deepcopy(labels_test)
            IEGM_test = torch.cat((IEGM_test, fft_transfer(IEGM_test)), 1)
            IEGM_test = IEGM_test.float()

            outputs_test = net_int8(IEGM_test)
            predicted_test = (outputs_test.data[:,1] > TH)

            if seg_label == 0:
                segs_FP += (labels_test.size(0) - (predicted_test == labels_test).sum()).item()
                segs_TN += (predicted_test == labels_test).sum().item()
            elif seg_label == 1:
                segs_FN += (labels_test.size(0) - (predicted_test == labels_test).sum()).item()
                segs_TP += (predicted_test == labels_test).sum().item()


    # report metrics
    stats_file.write('segments: TP, FN, FP, TN\n')
    output_segs = stats_report([segs_TP, segs_FN, segs_FP, segs_TN])
    stats_file.write(output_segs + '\n')
    stop = time.time()
    interval = stop - start
    print('interval: '+str(interval))
    torch.save(net_int8, './saved_models/Quantized_net.pkl')


if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument('--size', type=int, default=1250)
    argparser.add_argument('--th', type=float, help='threshold for label smoothing', default=0.44)
    argparser.add_argument('--path_data', type=str, default='./data/')
    argparser.add_argument('--path_net', type=str, default='./saved_models/')
    argparser.add_argument('--path_record', type=str, default='./records/')
    argparser.add_argument('--path_indices', type=str, default='./data_indices/')

    args = argparser.parse_args()

    device = torch.device('cpu')
    print("device is --------------", device)

    main()
